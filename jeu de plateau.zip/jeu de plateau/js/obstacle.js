// Obstacle objet. //
class Obstacle {
    constructor(x, y, img) {
        this.x = x;
        this.y = y;
        this.img = img;
    }
}
var obstacle = new Obstacle(0, 0, "./images/red_square.jpg");